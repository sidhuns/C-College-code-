
#include <iostream>
#include <string>
#include <sstream>
#include <cctype>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <vector> 
using namespace std;
int main(){
    int *pValue = new int;
    *pValue = 45;
    cout << *pValue << endl;
    pValue = new int;
    *pValue = 55;
    cout << *pValue << endl;
    


}